#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX 100
#define INF (INT_MAX / 4)

int mincost[MAX][MAX];
int visited[MAX];

int main(void) {
    FILE *file = fopen("graph.txt", "r");
    if (!file) return 1;

    int n;
    if (fscanf(file, "%d", &n) != 1 || n <= 0 || n > MAX) {
        fclose(file);
        return 1;
    }

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            int w;
            if (fscanf(file, "%d", &w) != 1) { fclose(file); return 1; }
            if (i == j) mincost[i][j] = 0;
            else if (w == 0) mincost[i][j] = INF;
            else mincost[i][j] = w;
        }
    }
    fclose(file);

    for (int i = 0; i < n; ++i) visited[i] = 0;

    printf("The edges of the minimum spanning tree are:\n");
    visited[0] = 1;
    int edges_taken = 0;
    long total_cost = 0;

    while (edges_taken < n - 1) {
        int min_edge = INF;
        int a = -1, b = -1;

        for (int i = 0; i < n; ++i) {
            if (visited[i]) {
                for (int j = 0; j < n; ++j) {
                    if (!visited[j] && mincost[i][j] < min_edge) {
                        min_edge = mincost[i][j];
                        a = i; b = j;
                    }
                }
            }
        }

        if (min_edge == INF || a == -1 || b == -1) {
            fprintf(stderr, "Graph is disconnected — MST not possible for all vertices\n");
            return 1;
        }

        visited[b] = 1;
        printf("Edge %d: (%d %d) cost: %d\n", edges_taken + 1, a, b, min_edge);
        total_cost += min_edge;
        edges_taken++;
    }

    printf("\nMinimum total cost: %ld\n", total_cost);
    return 0;
}
