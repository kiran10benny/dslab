#include <stdio.h>
#include <stdlib.h>

#define SIZE 5

int cqueue[SIZE];
int f = -1, r = -1;



int isfull(void) {
    return (f == 0 && r == SIZE - 1) || (f == (r + 1) % SIZE);
}

int isempty(void) {
    return (f == -1);
}

void enqueue(void) {
    int val;
    printf("Enter the value to insert: ");
    if (scanf("%d", &val) != 1) {
        printf("Invalid input.\n");
        // clear stdin
        int ch;
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        return;
    }

    if (isfull()) {
        printf("Queue full....\n");
        return;
    }
    if (f == -1)
        f = 0;

    r = (r + 1) % SIZE;
    cqueue[r] = val;
    printf("Element inserted is %d\n", val);
}

void dequeue(void) {
    if (isempty()) {
        printf("Queue empty.....\n");
        return;
    }
    int value = cqueue[f];
    printf("Value deleted is: %d\n", value);

    if (f == r)
        f = r = -1;
    else
        f = (f + 1) % SIZE;
}

void display(void) {
    if (isempty()) {
        printf("Empty queue...\n");
        return;
    }
    printf("Queue elements: ");
    int i = f;
    while (1) {
        printf("%d ", cqueue[i]);
        if (i == r) break;
        i = (i + 1) % SIZE;
    }
    printf("\n");
}

/* Improved search: prints all positions where value occurs (1-based position from front) */
void search(void) {
    if (isempty()) {
        printf("Queue is empty, cannot search.\n");
        return;
    }

    int val;
    printf("Enter the value to search: ");
    if (scanf("%d", &val) != 1) {
        printf("Invalid input.\n");
        int ch;
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        return;
    }

    int i = f;
    int pos = 1;        // position counting from front as 1
    int found = 0;

    printf("Searching for %d...\n", val);
    while (1) {
        if (cqueue[i] == val) {
            if (!found) {
                printf("Found at position(s): ");
            }
            printf("%d ", pos);
            found = 1;
            /* do not break — we want all occurrences */
        }

        if (i == r)
            break;

        i = (i + 1) % SIZE;
        pos++;
    }

    if (!found)
        printf("Element %d not found in the queue.\n", val);
    else
        printf("\n");
}

int main(void) {
    int choice;

    while (1) {
        printf("\n--- CIRCULAR QUEUE MENU ---\n");
        printf("1. Enqueue\n");
        printf("2. Dequeue\n");
        printf("3. Display\n");
        printf("4. Search\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number between 1 and 5.\n");
            int ch;
            while ((ch = getchar()) != '\n' && ch != EOF) {}
            continue;
        }

        switch (choice) {
            case 1:
                enqueue();
                break;

            case 2:
                dequeue();
                break;

            case 3:
                display();
                break;

            case 4:
                search();
                break;

            case 5:
                printf("Exiting...\n");
                return 0;

            default:
                printf("Invalid choice! Please enter 1-5.\n");
        }
    }

    return 0;
}
