#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX 10

typedef struct Node {
    int data;
    struct Node *next;
} Node;

Node* adj_list[MAX];
bool visited[MAX];

int vertex_count = 0;

Node* create_node(int vertex) {
    Node* new_node = (Node*)malloc(sizeof(Node));
    if (new_node == NULL) {
        fprintf(stderr, "Memory allocation failed.\n");
        exit(EXIT_FAILURE);
    }
    new_node->data = vertex;
    new_node->next = NULL;
    return new_node;
}

void init_graph(void) {
    for (int i = 0; i < MAX; ++i) {
        adj_list[i] = NULL;
        visited[i] = false;
    }
    vertex_count = 0;
}

void add_vertex(void) {
    if (vertex_count < MAX) {
        adj_list[vertex_count] = NULL;  /* start with empty adjacency list */
        printf("Vertex %d added.\n", vertex_count);
        vertex_count++;
    } else {
        printf("Maximum number of vertices reached.\n");
    }
}

void add_edge(int start, int end) {
    if (start < 0 || end < 0 || start >= vertex_count || end >= vertex_count) {
        printf("Invalid vertex. Valid vertices are 0 to %d.\n", vertex_count - 1);
        return;
    }
    /* directed edge start -> end */
    Node* new_node = create_node(end);
    new_node->next = adj_list[start];
    adj_list[start] = new_node;
    printf("Edge added from %d to %d.\n", start, end);
}

void bfs(int start) {
    if (start < 0 || start >= vertex_count) {
        printf("Invalid start vertex for BFS.\n");
        return;
    }

    for (int i = 0; i < vertex_count; ++i)
        visited[i] = false;

    int queue[MAX];
    int front = 0, rear = 0;

    visited[start] = true;
    queue[rear++] = start;

    printf("BFS traversal: ");
    while (front < rear) {
        int vertex = queue[front++];
        printf("%d ", vertex);

        Node* adj = adj_list[vertex];
        while (adj != NULL) {
            if (!visited[adj->data]) {
                visited[adj->data] = true;
                queue[rear++] = adj->data;
            }
            adj = adj->next;
        }
    }
    printf("\n");
}

void dfs_recursion(int vertex) {
    visited[vertex] = true;
    printf("%d ", vertex);
    Node* adj = adj_list[vertex];
    while (adj != NULL) {
        if (!visited[adj->data]) {
            dfs_recursion(adj->data);
        }
        adj = adj->next;
    }
}

void dfs(int start) {
    if (start < 0 || start >= vertex_count) {
        printf("Invalid start vertex for DFS.\n");
        return;
    }

    for (int i = 0; i < vertex_count; ++i)
        visited[i] = false;

    printf("DFS traversal: ");
    dfs_recursion(start);
    printf("\n");
}

void topo_sort_recursion(int vertex, int stack[], int *top) {
    visited[vertex] = true;
    Node* adj = adj_list[vertex];
    while (adj != NULL) {
        if (!visited[adj->data]) {
            topo_sort_recursion(adj->data, stack, top);
        }
        adj = adj->next;
    }
    stack[(*top)++] = vertex;
}

void topological_sort(void) {
    for (int i = 0; i < vertex_count; ++i)
        visited[i] = false;

    int stack[MAX];
    int top = 0;

    for (int i = 0; i < vertex_count; ++i) {
        if (!visited[i]) {
            topo_sort_recursion(i, stack, &top);
        }
    }

    printf("Topological Sort: ");
    while (top > 0) {
        printf("%d ", stack[--top]);
    }
    printf("\n");
}



int main(void) {
    init_graph();

    int choice, start, end, vertex;
    do {
        printf("\n1. Add Vertex\n2. Add Edge\n3. BFS\n4. DFS\n5. Topological Sort\n6. Exit\n");
        printf("Enter Your Choice: ");
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            int ch;
            while ((ch = getchar()) != '\n' && ch != EOF) {}
            continue;
        }

        switch (choice) {
            case 1:
                add_vertex();
                break;
            case 2:
                printf("Enter start and end vertex: ");
                if (scanf("%d %d", &start, &end) != 2) {
                    printf("Invalid input.\n");
                    int ch;
                    while ((ch = getchar()) != '\n' && ch != EOF) {}
                } else {
                    add_edge(start, end);
                }
                break;
            case 3:
                printf("Enter starting vertex for BFS: ");
                if (scanf("%d", &vertex) != 1) {
                    printf("Invalid input.\n");
                    int ch;
                    while ((ch = getchar()) != '\n' && ch != EOF) {}
                } else {
                    bfs(vertex);
                }
                break;
            case 4:
                printf("Enter starting vertex for DFS: ");
                if (scanf("%d", &vertex) != 1) {
                    printf("Invalid input.\n");
                    int ch;
                    while ((ch = getchar()) != '\n' && ch != EOF) {}
                } else {
                    dfs(vertex);
                }
                break;
            case 5:
                topological_sort();
                break;

            case 6:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice! Try again.\n");
        }
    } while (choice != 7);

    return 0;
}
